<?php

$footer = <<<HTML

<!-- footer -->
<div class="container">
  <div class="py-3">
    <div class="text-center">
      <h6>Copyright &#169; 2020 Wasted Archive</h6>
    </div>
  </div>
</div>

HTML;
