<?php

$dropdown = <<<HTML

<!-- dropdown list -->
<div class="container" id="dropdownList">
  <ul class="dropdown-list">
    <a href="#" class="text-grey">
      <li>Home</li>
    </a>
    <a href="https://id.pinterest.com/wastedarchive" class="text-grey">
      <li>Portofolio</li>
    </a>
    <a href="https://wastedarchive.bigcartel.com/" class="text-grey">
      <li>Shop</li>
    </a>
    <a href="https://www.youtube.com/channel/UC-BOx6ENuPJVIgXJG91kxfw" class="text-grey">
      <li>Video</li>
    </a>
    <a href="#" class="text-grey">
      <li>Collaboration</li>
    </a>
    <a href="about.html" class="text-grey">
      <li>About</li>
    </a>
    <a href="contact.html" class="text-grey">
      <li>Contact</li>
    </a>
  </ul>
</div>

HTML;
